# Scenario 1 — Single Tier App

This is the app referenced in **Scenario 1** of your `Docker_Mastery_Lab.docx` workbook.

## What's here
- `app.js` — an Express server that says Hello World on port 3000
- `package.json` — dependencies (just Express)

## What's NOT here (on purpose)
- `Dockerfile`
- `.dockerignore`

Those are **your tasks**. Write them yourself in this folder, following Tasks 1–5 of Scenario 1
in the workbook. Only check Section 6 of the workbook after you've attempted everything yourself.

## Quick local sanity check (without Docker, optional)
```bash
npm install
npm start
# visit http://localhost:3000
```

## Your job
1. Write `Dockerfile` (slim base image, non-root user, EXPOSE).
2. Write `.dockerignore`.
3. Build and run:
   ```bash
   docker build -t single-tier-app .
   docker run -p 3000:3000 single-tier-app
   ```
4. Confirm `localhost:3000` works in your browser.
5. Answer the "Think About This" question in the workbook (layer caching).
