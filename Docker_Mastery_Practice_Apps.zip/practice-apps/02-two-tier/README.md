# Scenario 2 — Two Tier App

This is the app referenced in **Scenario 2** of your `Docker_Mastery_Lab.docx` workbook.

## What's here
- `backend/` — Express REST API (in-memory task list) on port 3001
- `frontend/` — React (Vite) app that calls the backend API

## What's NOT here (on purpose)
- `frontend/Dockerfile`
- `backend/Dockerfile`
- `docker-compose.yml`

Those are **your tasks**. Write them yourself, following Tasks 1–6 of Scenario 2 in the workbook.

## Quick local sanity check (without Docker, optional)
```bash
cd backend && npm install && npm start
# in another terminal
cd frontend && npm install && npm run dev
# visit http://localhost:5173
```

## Your job
1. Write a `Dockerfile` for `backend/` (single-stage is fine here).
2. Write a multi-stage `Dockerfile` for `frontend/`:
   Stage 1 — `npm run build` with a Node image. Stage 2 — serve `dist/` with NGINX.
3. Write `docker-compose.yml` at the project root, with both services on a custom bridge network.
4. Set `VITE_API_URL` to the **backend service name**, not `localhost`
   (re-read the "Common Mistake" box in the workbook before you do this).
5. `docker-compose up --build` and confirm the frontend can fetch tasks from the backend.

Remember: `localhost` inside a container means the container itself, not your other container.
