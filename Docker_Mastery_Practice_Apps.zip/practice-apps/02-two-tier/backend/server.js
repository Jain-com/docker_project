const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// In-memory "database" — just for practice, resets on restart
let tasks = [
  { id: 1, title: 'Learn Docker basics', done: true },
  { id: 2, title: 'Write a Dockerfile', done: false },
  { id: 3, title: 'Write docker-compose.yml', done: false },
];

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'backend-api' });
});

app.get('/api/tasks', (req, res) => {
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const { title } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'title is required' });
  }
  const newTask = { id: tasks.length + 1, title, done: false };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

app.listen(PORT, () => {
  console.log(`Backend API listening on port ${PORT}`);
});
