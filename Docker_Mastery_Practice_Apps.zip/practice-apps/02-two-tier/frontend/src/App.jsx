import { useEffect, useState } from 'react';

// IMPORTANT (see workbook Common Mistake box):
// Do NOT hardcode http://localhost:3001 here when running in Docker.
// Use an env var set in docker-compose.yml that points to the backend
// SERVICE NAME, not localhost.
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [error, setError] = useState(null);

  const fetchTasks = () => {
    fetch(`${API_URL}/api/tasks`)
      .then((res) => res.json())
      .then(setTasks)
      .catch((err) => setError(err.message));
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const addTask = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    fetch(`${API_URL}/api/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    })
      .then((res) => res.json())
      .then(() => {
        setTitle('');
        fetchTasks();
      })
      .catch((err) => setError(err.message));
  };

  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: 480, margin: '60px auto' }}>
      <h1>Two-Tier Task App</h1>
      <p style={{ color: '#666' }}>
        Frontend (React/Vite) → Backend API at <code>{API_URL}</code>
      </p>

      {error && (
        <p style={{ color: 'red' }}>
          Could not reach backend: {error}. Is the backend service running?
        </p>
      )}

      <form onSubmit={addTask} style={{ marginBottom: 20 }}>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="New task"
          style={{ padding: 8, width: '70%' }}
        />
        <button type="submit" style={{ padding: 8, marginLeft: 8 }}>
          Add
        </button>
      </form>

      <ul>
        {tasks.map((t) => (
          <li key={t.id}>
            {t.done ? '✅' : '⬜'} {t.title}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
