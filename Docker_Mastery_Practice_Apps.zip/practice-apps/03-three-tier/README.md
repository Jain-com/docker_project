# Scenario 3 — Three Tier App

This is the app referenced in **Scenario 3** of your `Docker_Mastery_Lab.docx` workbook
(the same React + Node + MySQL stack you already deployed on AWS, now being containerized).

## What's here
- `frontend/` — React (Vite) app
- `backend/` — Express API that talks to MySQL via `mysql2` (retries connection on startup)
- `backend/db.sql` — schema + seed data for the `tasks` table

## What's NOT here (on purpose)
- `frontend/Dockerfile`
- `backend/Dockerfile`
- `docker-compose.yml`
- `.env`

Those are **your tasks**. Write them yourself, following Tasks 1–8 of Scenario 3 in the workbook.

## Your job
1. Add a MySQL service to `docker-compose.yml` using the official `mysql:8` image.
2. Create a `.env` file with `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`
   — and add it to `.gitignore` **immediately**, before anything else.
3. Add a named volume for MySQL data persistence.
4. Add a `healthcheck` to the MySQL service.
5. Add `depends_on` with `condition: service_healthy` on the backend.
6. Mount `backend/db.sql` into MySQL's init directory so it runs on first startup.
7. Write Dockerfiles for `frontend/` and `backend/`.
8. `docker-compose up --build` and confirm the full stack works end to end —
   add a task in the UI and refresh to prove it persisted in MySQL, not just memory.

## Once this works
Move on to **Scenario 4** (production hardening: multi-stage backend build, resource
limits, restart policies, NGINX reverse proxy) and **Scenario 5** (security hardening:
non-root users, dropped capabilities, Docker secrets, pinned image tags, Trivy scan)
in the same workbook — applied on top of this same three-tier app.

Only check Section 6 of the workbook after attempting each task yourself.
