-- This file should be mounted into the MySQL container so it runs
-- automatically on first startup (see Scenario 3, Task 7 in the workbook).

CREATE TABLE IF NOT EXISTS tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  done BOOLEAN NOT NULL DEFAULT false
);

INSERT INTO tasks (title, done) VALUES
  ('Learn Docker basics', true),
  ('Containerize the frontend', false),
  ('Containerize the backend', false),
  ('Add MySQL with a named volume', false),
  ('Add a healthcheck to MySQL', false);
