const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// DB connection config comes from environment variables.
// In Scenario 3 these should be supplied via a .env file referenced
// in docker-compose.yml — never hardcode credentials here.
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'appuser',
  password: process.env.DB_PASSWORD || 'changeme',
  database: process.env.DB_NAME || 'appdb',
};

let pool;

// MySQL can take a few seconds to become ready. Retry the connection
// instead of crashing immediately — this is also why the workbook asks
// you to add a healthcheck + depends_on condition in compose.
async function connectWithRetry(retries = 10, delayMs = 3000) {
  for (let i = 1; i <= retries; i++) {
    try {
      pool = mysql.createPool(dbConfig);
      await pool.query('SELECT 1');
      console.log('Connected to MySQL');
      return;
    } catch (err) {
      console.log(`MySQL not ready yet (attempt ${i}/${retries}): ${err.message}`);
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  console.error('Could not connect to MySQL after retries. Exiting.');
  process.exit(1);
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'backend-api' });
});

app.get('/api/tasks', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, title, done FROM tasks ORDER BY id');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tasks', async (req, res) => {
  const { title } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'title is required' });
  }
  try {
    const [result] = await pool.query('INSERT INTO tasks (title, done) VALUES (?, false)', [title]);
    res.status(201).json({ id: result.insertId, title, done: false });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

connectWithRetry().then(() => {
  app.listen(PORT, () => {
    console.log(`Backend API listening on port ${PORT}`);
  });
});
