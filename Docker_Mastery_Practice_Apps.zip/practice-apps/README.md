# Docker Mastery — Practice Apps

These are the three apps referenced in your **Docker_Mastery_Lab.docx** workbook
(Scenarios 1, 2, and 3). The application code is already written for you —
exactly like the workbook says, your job is the Docker infrastructure around it,
not the app logic itself.

| Folder | Workbook Scenario | Stack |
|---|---|---|
| `01-single-tier/` | Scenario 1 | Node.js + Express |
| `02-two-tier/` | Scenario 2 | React (Vite) + Node.js API |
| `03-three-tier/` | Scenario 3 | React + Node.js + MySQL |

## How to use this

1. Open the workbook (`Docker_Mastery_Lab.docx`) and the matching folder side by side.
2. Read that scenario's "About this app" and "Your Tasks" sections.
3. Write the Dockerfile(s) / `.dockerignore` / `docker-compose.yml` / `.env` yourself,
   inside the relevant folder — none of these files are included here on purpose.
4. Build and run it. Get it working end to end.
5. Only THEN open Section 6 of the workbook to check your work against the reference.
6. Once Scenario 3 works, keep going — Scenarios 4 (production-ready) and 5
   (security hardened) in the workbook build directly on top of this same three-tier app,
   no new app code needed.

## A note on running these
Each folder's own `README.md` has a "quick local sanity check" command so you can confirm
the app itself runs fine with plain `node`/`npm` before you containerize it — that way,
if something breaks later, you'll know it's a Docker issue and not an app issue.

Good luck — this mirrors real DevOps work: you're given working application code and
asked to package, network, and harden it, which is exactly what you'll do on the job.
